mod rust_io;

use rust_io::string_to_i32;
use rust_io::input;



fn main() {
    loop {
        std::process::Command::new("clear").status().unwrap();
        println!("Toplama için 1,\nÇıkarma için 2,\nÇarpma için 3,\nBölme için 4,\nÇıkış için 5'e bas.");
        let işlem = input();

        if işlem.trim() == String::from("5") {
            println!("Görüşürüz!");
            break;
        }
        if işlem.trim() != String::from("1") && işlem.trim() != String::from("2") && işlem.trim() != String::from("3") && işlem.trim() != String::from("4") {
            println!("Geçerli değil.(Devam etmek için enter'a bas.)");
            input();
            continue;
        }

        println!("İlk sayıyı gir.");
        let num1 = input();

        println!("İkinci sayıyı gir.");
        let num2 = input();

        let num1 = string_to_i32(num1);
        let num2 = string_to_i32(num2);
        
        let sonuç: i32 = match &(işlem.trim()) as &str {
            "1" => num1+num2,
            "2" => num1-num2,
            "3" => num1*num2,
            "4" => {
                if num2 == 0 {panic!("Herhangi bir sayıyı sıfıra bölemezsin!");}
                else {num1/num2}
            },
            &_ => todo!(),
        };
        println!("Sonuç:{sonuç}");

        println!("Uygulamayı kullanmaya devam etmek istiyor musun(e/H)?");
        let devam = input();
        if devam.trim().to_lowercase() == "e" {
            continue;
        }
        else {
            println!("Görüşürüz!");
            break;
        }
        
    }

}